## Guía de Empaquetado para "AppBanco" utilizando PyInstaller

Este documento proporciona los pasos para empaquetar la aplicación de la calculadora utilizando **PyInstaller**, para crear un archivo ejecutable que se pueda distribuir y ejecutar en otros sistemas.

### Requisitos previos

Antes de empaquetar la aplicación, asegúrate de tener instalado lo siguiente:

1. **Python 3.x**: preferentemente la versión 3.10 o superior ya que es la usada durante el desarrollo.
2. **PyInstaller**: Para instalar PyInstaller, ejecuta el siguiente comando en tu terminal:
```bash
   pip install pyinstaller
```

### Empaquetado

Para empaquetar la aplicación simplemente ejecuta el suguiente comando en tu terminal (en el empaquetado no se ha incluido un icono de ejecutable, ya que este estaba causando un error que marcaba al ejecutable como un virus ante windows defender):
```bash
   pyinstaller --name "AppBanco" --noconsole --add-data "local_db.db;." --add-data "assets;assets" main.py
```

#### Partes del comando:

- **`--name "AppBanco"`**: Establece el nombre del ejecutable resultante como **AppBanco**.

- **`--noconsole`**: Evita que se abra una consola de texto al ejecutar la aplicación, lo cual es ideal para aplicaciones con interfaz gráfica (GUI).

- **`--add-data`**: Añade los archivos a la distribución. El **punto (.)** indica que el archivo se colocará en la misma carpeta que el ejecutable.

- **`main.py`**: Es el archivo Python principal que será empaquetado.