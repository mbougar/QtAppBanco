# Banco CostaSur
![logo](./assets/iconoBanco.svg)
---
# Esquema Base de Datos
![basededatos](./esquema.png)

# Pantallazo Firebase con datos usuario
![firebase](./firebase.png)